<?php
session_start();
$id = $_SESSION['usuario']['id'];
$nome = $_SESSION['usuario']['nome'];
$foto = $_SESSION['usuario']['foto'];
?>

<style>
.botao-flutuante {
  position: fixed;
  top: 10px;
  right: 10px;
  z-index: 1000;
  border: none;
  background: none;
  cursor: pointer;
}
</style>

<!-- Botão flutuante -->
<form action='perfil.php' method='POST'>
  <input type='hidden' name='id' value='<?php echo $_SESSION["usuario"]["id"]; ?>'>
  <button class='botao-flutuante'>
    <img src='<?php echo $foto; ?>' alt='Perfil de <?php echo $nome; ?>' style='width: 50px; height: 50px; border-radius: 50%;'>
  </button>
</form>