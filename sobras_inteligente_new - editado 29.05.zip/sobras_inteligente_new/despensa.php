<?php

require_once 'navbar.php';/*Chama o icone flutuante*/

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>SmartKitchen - Despensa</title>
  <style>

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: url('imagens/despensa-de-alimentos.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    nav {
      width: 100%;
      display: flex;
      justify-content: space-between;
      padding: 10px 20px;
      background: rgba(0, 0, 0, 0.5);
      box-sizing: border-box;
    }

    .nav-left, .nav-right {
      display: flex;
      align-items: center;
    }

    button {
      background-color: #4caf50;
      border: none;
      padding: 10px 20px;
      border-radius: 10px;
      color: white;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease;
      margin: 5px;
    }

    button:hover {
      background-color: #388e3c;
    }

    main {
      background: rgba(0, 0, 0, 0.6);
      margin-top: 20px;
      padding: 20px;
      border-radius: 15px;
      max-width: 900px;
      width: 90%;
      box-sizing: border-box;
      color: #fff;
      max-height: 1200px;
      overflow-y: auto;
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: #222;
      border-radius: 10px;
      overflow: hidden;
    }

    th, td {
      padding: 12px 10px;
      text-align: center;
      border-bottom: 1px solid #444;
    }

    th {
      background-color: #4caf50;
      color: #fff;
    }

    tbody tr:hover {
      background-color: rgba(76, 175, 80, 0.3);
    }

    .btn-container {
      display: flex;
      justify-content: center;
      margin-top: 15px;
    }

    .checkbox {
      transform: scale(1.3);
    }

    .edit-btn {
      background-color: #2196f3;
    }

    .delete-btn {
      background-color: #f44336;
    }

    .edit-btn:hover {
      background-color: #1976d2;
    }

    .delete-btn:hover {
      background-color: #d32f2f;
    }

    .used {
      text-decoration: line-through;
      opacity: 0.6;
    }

    /* Estilo para a caixinha de legenda */
    #legenda-unidade {
      max-width: 900px;
      width: 90%;
      margin: 15px auto 30px auto;
      padding: 12px 20px;
      background-color: rgba(255, 255, 255, 0.9);
      color: #222;
      border-radius: 10px;
      font-size: 15px;
      box-shadow: 0 0 10px rgba(0,0,0,0.3);
      font-weight: 600;
      line-height: 1.4;
    }

    #legenda-unidade strong {
      color: #4caf50;
    }

    /* Modal Styles */
    #modal {
      display: none;
      position: fixed;
      z-index: 9999;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.6);
      justify-content: center;
      align-items: center;
    }

    #modalContent {
      background-color: #222;
      padding: 20px 30px;
      border-radius: 12px;
      width: 320px;
      color: white;
      box-sizing: border-box;
      font-weight: 600;
    }

    #modalContent label {
      display: block;
      margin-bottom: 6px;
      font-size: 14px;
    }

    #modalContent input {
      width: 100%;
      padding: 8px;
      border-radius: 8px;
      border: none;
      margin-bottom: 16px;
      font-size: 16px;
      box-sizing: border-box;
      font-weight: 600;
    }

    #modalContent .btn-row {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }

    #modalContent .btn-row button {
      flex: 1;
      padding: 10px 0;
      font-weight: 700;
      border-radius: 8px;
      border: none;
      cursor: pointer;
    }

    #btnSalvar {
      background-color: #4caf50;
      color: white;
    }

    #btnCancelar {
      background-color: #888;
      color: white;
    }

    #btnSalvar:hover {
      background-color: #388e3c;
    }

    #btnCancelar:hover {
      background-color: #666;
    }

    /* CSS do Botão de Gerar Receita */
    .gerar-receita-btn {
      background-color: #4caf50;
      border: none;
      padding: 15px 30px;
      font-size: 25px;
      font-weight: bold;
      border-radius: 10px;
      color: white;
      cursor: pointer;
      margin-top: 20px;
    }

    .gerar-receita-btn:hover {
      background-color: #388e3c;
      transition: background-color 0.3s ease;
    }

  </style>
</head>
<body>

  <nav>
    <div class="nav-left">
      <button onclick="window.location.href='home.php'">Voltar</button>
    </div>
    <div class="nav-right">
      <button onclick="window.location.href='livro_de_receitas.php'">Ir para Livro de Receitas</button>
    </div>
  </nav>

  <main>
    <form action="receitas.php" method="POST" onsubmit="return validarSelecao()">
      
      <h2>Despensa</h2>
      
      <table>
        <thead>
          <tr>
            <th>✓</th>
            <th>Ingrediente</th>
            <th>Quantidade</th>
            <th>Unidade</th>
            <th>Validade</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody id="tabela-despensa"></tbody>
      </table>
      
      <div class="btn-container">
        <button type="button" onclick="abrirModal()">Adicionar Novo Ingrediente</button>
      </div>
    
      <!-- Botão de Gerar Receita -->
      <div class="btn-container">
        <input type="submit" value="Gerar Receita" class="gerar-receita-btn">
      </div>

    </form>

  </main>

  <!-- Caixinha de legenda da Unidade, abaixo do main
  <div id="legenda-unidade">
    <strong>Unidade:</strong> Kg = Quilograma, L = Litros, Un = Unidades. Você pode digitar manualmente no campo unidade ao adicionar ou editar um ingrediente.
  </div> -->

  <!-- Modal para adicionar/editar item -->
  <div id="modal">
    <div id="modalContent">
      <form id="formItem" onsubmit="return salvarItem(event)">
        <label for="nomeInput">Nome do ingrediente:</label>
        <input type="text" id="nomeInput" autocomplete="off" required />

        <label for="quantidadeInput">Quantidade:</label>
        <input type="number" id="quantidadeInput" min="0.01" step="0.01" autocomplete="off" required />

        <label for="unidadeInput">Unidade (ex: kg, g, L, un):</label>
        <input type="text" id="unidadeInput" autocomplete="off" required />

        <label for="validadeInput">Data de validade:</label>
        <input type="text" id="validadeInput" maxlength="10" placeholder="DD/MM/AAAA" autocomplete="off" required />

        <div class="btn-row">
          <button type="button" id="btnCancelar" onclick="fecharModal()">Cancelar</button>
          <button type="submit" id="btnSalvar">Salvar</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    let itensDespensa = JSON.parse(localStorage.getItem('itensDespensa')) || [
      { nome: "Arroz", quantidade: 2, unidade: "kg", validade: "28/11/2025", usado: false },
      { nome: "Feijão", quantidade: 1, unidade: "kg", validade: "15/12/2025", usado: false },
      { nome: "Azeite", quantidade: 3, unidade: "L", validade: "21/03/2026", usado: false },
    ];

    let indiceEdicao = null; // guarda índice para edição ou null para novo

    const modal = document.getElementById('modal');
    const nomeInput = document.getElementById('nomeInput');
    const quantidadeInput = document.getElementById('quantidadeInput');
    const unidadeInput = document.getElementById('unidadeInput');
    const validadeInput = document.getElementById('validadeInput');
    const formItem = document.getElementById('formItem');

    function salvarItens() {
      localStorage.setItem('itensDespensa', JSON.stringify(itensDespensa));
    }

    function renderizarTabela() {
      const tbody = document.getElementById('tabela-despensa');
      tbody.innerHTML = '';

      itensDespensa.forEach((item, index) => {
        const tr = document.createElement('tr');
        tr.className = item.usado ? 'used' : '';

        tr.innerHTML = `
          <td>
            <input type="checkbox" class="checkbox" name="ingredientes[]" value="${item.nome}" ${item.usado ? 'checked' : ''} onchange="marcarUsado(${index})" />
          </td>
          <td>${item.nome}</td>
          <td>${item.quantidade}</td>
          <td>${item.unidade}</td>
          <td>${item.validade}</td>
          <td>
            <button type="button" class="edit-btn" onclick="abrirModal(${index})">Editar</button>
            <button type="button" class="delete-btn" onclick="excluirItem(${index})">Excluir</button>
          </td>
        `;

        tbody.appendChild(tr);
      });
    }

    function abrirModal(index) {
      indiceEdicao = (typeof index === 'number') ? index : null;

      if (indiceEdicao !== null) {
        // Preenche formulário com dados do item para editar
        const item = itensDespensa[indiceEdicao];
        nomeInput.value = item.nome;
        quantidadeInput.value = item.quantidade;
        unidadeInput.value = item.unidade;
        validadeInput.value = item.validade;
      } else {
        // Limpa o formulário para novo item
        nomeInput.value = '';
        quantidadeInput.value = '';
        unidadeInput.value = '';
        validadeInput.value = '';
      }

      modal.style.display = 'flex';
      nomeInput.focus();
    }

    function fecharModal() {
      modal.style.display = 'none';
      indiceEdicao = null;
      formItem.reset();
    }

    function validarData(dataStr) {
      // Espera data no formato DD/MM/AAAA
      const partes = dataStr.split('/');
      if (partes.length !== 3) return false;

      const dia = parseInt(partes[0], 10);
      const mes = parseInt(partes[1], 10);
      const ano = parseInt(partes[2], 10);

      if (isNaN(dia) || isNaN(mes) || isNaN(ano)) return false;
      if (ano < 1900 || ano > 2100) return false;
      if (mes < 1 || mes > 12) return false;

      // Verifica dias conforme mês
      const diasPorMes = [31, (ano % 4 === 0 && (ano % 100 !== 0 || ano % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      if (dia < 1 || dia > diasPorMes[mes - 1]) return false;

      return true;
    }

    // Máscara automática para validade no formato DD/MM/AAAA
    validadeInput.addEventListener('input', function (e) {
      let valor = validadeInput.value;

      // Remove tudo que não for número
      valor = valor.replace(/\D/g, '');

      if (valor.length > 8) valor = valor.slice(0, 8);

      // Adiciona barras automaticamente
      if (valor.length > 4) {
        valor = valor.replace(/^(\d{2})(\d{2})(\d{1,4}).*/, '$1/$2/$3');
      } else if (valor.length > 2) {
        valor = valor.replace(/^(\d{2})(\d{1,2})/, '$1/$2');
      }

      validadeInput.value = valor;
    });

    function salvarItem(event) {
      event.preventDefault();

      const nome = nomeInput.value.trim();
      const quantidade = parseFloat(quantidadeInput.value);
      const unidade = unidadeInput.value.trim();
      const validade = validadeInput.value.trim();

      if (!nome) {
        alert('Nome do ingrediente é obrigatório.');
        nomeInput.focus();
        return false;
      }

      if (isNaN(quantidade) || quantidade <= 0) {
        alert('Quantidade inválida.');
        quantidadeInput.focus();
        return false;
      }

      if (!unidade) {
        alert('Unidade é obrigatória.');
        unidadeInput.focus();
        return false;
      }

      if (!validade || !validarData(validade)) {
        alert('Data de validade inválida. Use o formato DD/MM/AAAA.');
        validadeInput.focus();
        return false;
      }

      const novoItem = {
        nome,
        quantidade,
        unidade,
        validade,
        usado: false
      };

      if (indiceEdicao !== null) {
        // Atualiza item existente
        novoItem.usado = itensDespensa[indiceEdicao].usado; // preserva status usado
        itensDespensa[indiceEdicao] = novoItem;
      } else {
        // Adiciona novo item
        itensDespensa.push(novoItem);
      }

      salvarItens();
      renderizarTabela();
      fecharModal();

      return false;
    }

    function excluirItem(index) {
      if (confirm(`Deseja realmente excluir o ingrediente "${itensDespensa[index].nome}"?`)) {
        itensDespensa.splice(index, 1);
        salvarItens();
        renderizarTabela();
      }
    }

    function marcarUsado(index) {
      itensDespensa[index].usado = !itensDespensa[index].usado;
      salvarItens();
      renderizarTabela();
    }

    // Fecha modal ao clicar fora do conteúdo
    window.addEventListener('click', function(event) {
      if (event.target === modal) fecharModal();
    });

    // Renderiza tabela ao carregar a página
    renderizarTabela();

  </script>





</body>
</html>
