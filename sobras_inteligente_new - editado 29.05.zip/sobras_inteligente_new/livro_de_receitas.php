<?php

require_once 'navbar.php';/*Chama o icone flutuante*/

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Livro de Receitas</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: url('imagens/livro-de-receitas.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    header {
      background-color: rgba(0, 0, 0, 0.6);
      padding: 20px;
      text-align: center;
    }

    header h1 {
      margin: 0;
      font-size: 2rem;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background: rgba(0, 0, 0, 0.5);
    }

    nav button {
      background-color: #ff9800;
      color: white;
      border: none;
      padding: 10px 20px;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    nav button:hover {
      background-color: #e68900;
    }

    main {
      flex: 1;
      padding: 20px;
      background-color: rgba(0, 0, 0, 0.6);
      margin: 20px auto 40px;
      width: 90%;
      max-width: 900px;
      border-radius: 15px;
      box-sizing: border-box;
      overflow-y: auto;
      max-height: 80vh;
    }

    form {
      background: rgba(255, 255, 255, 0.1);
      padding: 20px;
      border-radius: 10px;
      margin-bottom: 20px;
    }

    form label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
      color: #ffc107;
    }

    form input[type="text"],
    form textarea {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border-radius: 6px;
      border: none;
      font-size: 1rem;
      resize: vertical;
    }

    form input[type="file"] {
      margin-top: 5px;
    }

    form button {
      margin-top: 15px;
      background-color: #4caf50;
      border: none;
      color: white;
      padding: 12px 25px;
      font-size: 1rem;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    form button:hover {
      background-color: #388e3c;
    }

    #toggleReceitasBtn {
      background-color: #2196f3;
      margin-bottom: 15px;
      width: 100%;
      font-size: 1.1rem;
    }
    #toggleReceitasBtn:hover {
      background-color: #0b7dda;
    }

    .receita {
      background-color: rgba(255, 255, 255, 0.1);
      padding: 20px;
      border-radius: 12px;
      margin-bottom: 25px;
      position: relative;
    }

    .receita h2 {
      margin-top: 0;
      color: #ffc107;
    }

    .receita ul {
      padding-left: 20px;
    }

    .receita img {
      max-width: 100%;
      max-height: 200px;
      margin-top: 10px;
      border-radius: 10px;
      object-fit: cover;
    }

    .receita-buttons {
      position: absolute;
      top: 20px;
      right: 20px;
    }

    .receita-buttons button {
      background-color: #ff5722;
      border: none;
      color: white;
      padding: 6px 12px;
      margin-left: 10px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .receita-buttons button.edit-btn {
      background-color: #03a9f4;
    }

    .receita-buttons button:hover {
      opacity: 0.8;
    }
  </style>
</head>
<body>

  <nav>
    <button onclick="window.location.href='despensa.php'">Retornar à Despensa</button>
    <button onclick="window.location.href='home.php'">Voltar à Home</button>
  </nav>

  <header>
    <h1>Livro de Receitas</h1>
  </header>

  <main>
    <form id="formReceita">
      <label for="nomeReceita">Nome da Receita:</label>
      <input type="text" id="nomeReceita" required />

      <label for="ingredientes">Ingredientes (separe por vírgula):</label>
      <textarea id="ingredientes" rows="3" placeholder="Ex: 2 xícaras de arroz, 1 cebola picada, 2 dentes de alho" required></textarea>

      <label for="utensilios">Utensílios (separe por vírgula):</label>
      <textarea id="utensilios" rows="2" placeholder="Ex: liquidificador, forma de bolo, copo medidor" required></textarea>

      <label for="modoPreparo">Modo de preparo:</label>
      <textarea id="modoPreparo" rows="4" placeholder="Descreva o modo de preparo..." required></textarea>

      <label for="imagemReceita">Imagem da Receita (opcional):</label>
      <input type="file" id="imagemReceita" accept="image/*" />

      <button type="submit">Adicionar / Atualizar Receita</button>
    </form>

    <button id="toggleReceitasBtn">Mostrar Receitas Salvas</button>

    <section id="listaReceitas" style="display:none;"></section>
  </main>

  <script>
    // Referências de elementos
    const form = document.getElementById('formReceita');
    const nomeInput = document.getElementById('nomeReceita');
    const ingredientesInput = document.getElementById('ingredientes');
    const utensiliosInput = document.getElementById('utensilios');
    const modoPreparoInput = document.getElementById('modoPreparo');
    const imagemInput = document.getElementById('imagemReceita');
    const listaReceitas = document.getElementById('listaReceitas');
    const toggleBtn = document.getElementById('toggleReceitasBtn');

    let receitas = JSON.parse(localStorage.getItem('receitas')) || [];
    let editIndex = -1; // -1 = adicionando, >=0 = editando receita

    function salvarReceitas() {
      localStorage.setItem('receitas', JSON.stringify(receitas));
    }

    function criarReceitaHTML(receita, index) {
      return `
      <article class="receita">
        <div class="receita-buttons">
          <button class="edit-btn" onclick="editarReceita(${index})">Editar</button>
          <button onclick="excluirReceita(${index})">Excluir</button>
        </div>
        <h2>${receita.nome}</h2>
        <p><strong>Ingredientes:</strong></p>
        <ul>${receita.ingredientes.map(i => `<li>${i.trim()}</li>`).join('')}</ul>
        <p><strong>Utensílios:</strong></p>
        <ul>${receita.utensilios.map(u => `<li>${u.trim()}</li>`).join('')}</ul>
        <p><strong>Modo de preparo:</strong></p>
        <p>${receita.modoPreparo}</p>
        ${receita.imagem ? `<img src="${receita.imagem}" alt="Imagem da receita ${receita.nome}"/>` : ''}
      </article>
      `;
    }

    function renderizarReceitas() {
      if(receitas.length === 0) {
        listaReceitas.innerHTML = '<p>Nenhuma receita salva.</p>';
        return;
      }
      listaReceitas.innerHTML = receitas.map(criarReceitaHTML).join('');
    }

    function limparFormulario() {
      form.reset();
      editIndex = -1;
      form.querySelector('button[type="submit"]').textContent = 'Adicionar Receita';
    }

    // Ao enviar o formulário: adicionar ou atualizar receita
    form.addEventListener('submit', e => {
      e.preventDefault();

      const nome = nomeInput.value.trim();
      const ingredientes = ingredientesInput.value.split(',').map(i => i.trim()).filter(i => i);
      const utensilios = utensiliosInput.value.split(',').map(u => u.trim()).filter(u => u);
      const modoPreparo = modoPreparoInput.value.trim();

      if (!nome || ingredientes.length === 0 || utensilios.length === 0 || !modoPreparo) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
      }

      // Função para converter a imagem em base64 (para salvar no localStorage)
      function lerImagemComoBase64(file) {
        return new Promise((resolve, reject) => {
          if (!file) resolve('');
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = error => reject(error);
          reader.readAsDataURL(file);
        });
      }

      lerImagemComoBase64(imagemInput.files[0])
        .then(base64Img => {
          const novaReceita = { nome, ingredientes, utensilios, modoPreparo, imagem: base64Img };

          if (editIndex >= 0) {
            // Atualiza receita existente
            receitas[editIndex] = novaReceita;
          } else {
            // Adiciona nova receita
            receitas.push(novaReceita);
          }
          salvarReceitas();
          renderizarReceitas();
          limparFormulario();
          if(listaReceitas.style.display === 'none') {
            toggleReceitas(); // Mostra receitas se estava oculto
          }
        })
        .catch(err => {
          alert('Erro ao processar a imagem.');
          console.error(err);
        });
    });

    function editarReceita(index) {
      const receita = receitas[index];
      nomeInput.value = receita.nome;
      ingredientesInput.value = receita.ingredientes.join(', ');
      utensiliosInput.value = receita.utensilios.join(', ');
      modoPreparoInput.value = receita.modoPreparo;
      // Imagem não pode ser carregada no input file por questões de segurança
      editIndex = index;
      form.querySelector('button[type="submit"]').textContent = 'Atualizar Receita';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function excluirReceita(index) {
      if (confirm(`Excluir a receita "${receitas[index].nome}"?`)) {
        receitas.splice(index, 1);
        salvarReceitas();
        renderizarReceitas();
        limparFormulario();
      }
    }

    function toggleReceitas() {
      if (listaReceitas.style.display === 'none') {
        listaReceitas.style.display = 'block';
        toggleBtn.textContent = 'Ocultar Receitas Salvas';
        renderizarReceitas();
      } else {
        listaReceitas.style.display = 'none';
        toggleBtn.textContent = 'Mostrar Receitas Salvas';
      }
    }

    toggleBtn.addEventListener('click', toggleReceitas);

    // Carrega receitas ao abrir a página, mas mantem ocultas
    window.onload = () => {
      if(receitas.length > 0) {
        renderizarReceitas();
        listaReceitas.style.display = 'none';
        toggleBtn.textContent = 'Mostrar Receitas Salvas';
      } else {
        listaReceitas.innerHTML = '<p>Nenhuma receita salva.</p>';
        listaReceitas.style.display = 'block';
        toggleBtn.style.display = 'none';
      }
    };
  </script>

</body>
</html>
